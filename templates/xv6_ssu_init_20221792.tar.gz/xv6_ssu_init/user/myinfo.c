#include "types.h"
#include "user.h"
#include "stat.h"

int
main()
{
	printf(1, "ID : 20221792\n");
	printf(1, "Name : Joonyeong Park\n");
	exit();
}
